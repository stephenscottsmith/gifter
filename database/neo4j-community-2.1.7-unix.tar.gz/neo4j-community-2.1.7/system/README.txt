Neo4j System
=======================================

The system directory contains runtime libraries and resources
required by Neo4j. 

These are not the droids you're looking for.


